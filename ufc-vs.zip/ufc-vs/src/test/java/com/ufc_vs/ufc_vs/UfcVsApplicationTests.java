package com.ufc_vs.ufc_vs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UfcVsApplicationTests {

	@Test
	void contextLoads() {
	}

}
