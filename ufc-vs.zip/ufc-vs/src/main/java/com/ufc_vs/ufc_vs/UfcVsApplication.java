package com.ufc_vs.ufc_vs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UfcVsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UfcVsApplication.class, args);
	}

}
